﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MenuController : MonoBehaviour
{
    [SerializeField] private GameObject startPreloadFrame;
    [SerializeField] private GameObject preloadFrame;
    [SerializeField] private GameObject touchScreen;
    [SerializeField] private Canvas canvas;
    [SerializeField] private GameObject player;
    [SerializeField] private float jumpPower = 160.0f;
    public float delayLoad;
    private Rigidbody2D myRigidbody;
    private Animator animatorPlayer;
    private bool move = false;
    private Vector3 speedMove = new Vector3(5f, 0f, 0f);
    private int countJump = 0;

    void Start()
    {
        startPreloadFrame.SetActive(true);
        animatorPlayer = player.GetComponent<Animator>();
        myRigidbody = player.GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        MoveCharacter();
    }

    public void StartGame()
    {
        move = true;
        Destroy(touchScreen);
        animatorPlayer.SetInteger("State", 1);
    }

    private void MoveCharacter()
    {
        if (move)
        {
            player.transform.Translate(speedMove * Time.deltaTime);
        }
        if (player.transform.position.x > 6f)
        {
            if(countJump==0)
            {
                animatorPlayer.SetInteger("State", 2);
                myRigidbody.AddForce(Vector3.up * (jumpPower * myRigidbody.mass * myRigidbody.gravityScale));
                countJump++;
                Instantiate(preloadFrame, Vector3.zero, Quaternion.identity, canvas.transform);
                Invoke("LoadGame", delayLoad);
            }
        }
    }

    void LoadGame()
    {
        Application.LoadLevel("Game");
    }

    public void ExitApp()
    {
        Application.Quit();
    }
}
