﻿    using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Flickering : MonoBehaviour {
    private SpriteRenderer sprite;
    private Color color;
    private bool visible = true;

	void Start ()
    {
        sprite = GetComponent<SpriteRenderer>();
        color = sprite.color;
	}
	
	void Update ()
    {
        if (visible)
        {
            color.a -= Time.deltaTime * 0.5f;
            sprite.color = color;
            if(color.a <= 0)
            {
                visible = false;
            }
        }
        else
            color.a += Time.deltaTime * 0.7f;
            sprite.color = color;
        if (color.a >= 1)
        {
            visible = true;
        }
    }
}
