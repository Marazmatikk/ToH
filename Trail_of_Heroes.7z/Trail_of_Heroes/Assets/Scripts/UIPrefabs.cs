﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIPrefabs : MonoBehaviour {
    [SerializeField] private GameObject whiteFrame;

    public void Continue()
    {
        Destroy(gameObject);
        Time.timeScale = 1;
    }

    public void Restart()
    {
        Application.LoadLevel("Game");
    }

    public void Menu()
    {
        Time.timeScale = 1f;
        Instantiate(whiteFrame, Vector3.zero, Quaternion.identity, gameObject.transform);
        Invoke("LoadScene", 1.2f);
    }

    private void LoadScene()
    {
        Application.LoadLevel("Menu");
    }
}
